const SuccessMessage = () => {
  return (
    <section className="success-alert">
      <p>successfully added to bag!</p>
    </section>
  );
}

export default SuccessMessage;
